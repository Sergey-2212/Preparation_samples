package lesson1.figure;

public interface Figure {

    float volume();
    float length();
    String getColour();

}
