package lesson1.figure;public class Square {
}
